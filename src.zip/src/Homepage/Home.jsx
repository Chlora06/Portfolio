import Myphoto from '../img/Myphoto.png'
import ins from '../img/ins.png';
import github from '../img/github.png';
import indeed from '../img/indeed.png';

import TypingAnimation from './TypingAnimation';

const Home = () => {

  return (
    <div className="homepage">
      <div className="homepage-title">
        <div className="homepage-title-container">
          <p className="homepage-title-hello">Hello, I&apos;m...</p>
          <p className="homepage-title-name">
            <TypingAnimation text="Zaijing Liu" speed={250}/>
            </p>
          
          <p className="homepage-title-role">
             UX Designer<br />& A front-end Developer
          </p>
        </div>

        <div className="homepage-icon">
          <img src={ins} alt="ins-icon" />
          <img src={github} alt="ins-icon" />
          <img src={indeed} alt="ins-icon" />
        </div>
      </div>

      <div className="homepage-photo">
        
        <img
          className="homepage-photo-img Myself"
          src={Myphoto}
          alt="My photo"
        />
      </div>
    </div>
  );
}

export default Home
