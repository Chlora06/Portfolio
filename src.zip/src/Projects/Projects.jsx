import project4 from '../img/project4.png'

const Projects = () => {
  return (
    <div className="projects">
      <p className="projects title">My projects</p>
      <div className="projects-container">
        <div className="projects-container-project project1">
          <img src="" alt="project1" />
        </div>
        <div className="projects-container-project project2">
          <img src="" alt="project2" />
        </div>
        <div className="projects-container-project project3">
          <img src="" alt="project3" />
        </div>
        <div className="projects-container-project project4">
          <img src={project4} alt="project4" />
        </div>
      </div>
    </div>
  );
}

export default Projects
